#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import socket
import select
import sys
import threading

LISTEN_ADDR = '0.0.0.0'
LISTEN_PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 80
BUFFER_SIZE = 4096
DEFAULT_HOST = b'127.0.0.1:22'
RESPONSE = b"HTTP/1.1 200 Connection established\r\n\r\n"


def handle_client(client_socket):
    try:
        data = client_socket.recv(BUFFER_SIZE)
        if not data:
            client_socket.close()
            return

        host = DEFAULT_HOST

        # Buscar X-Real-Host
        for line in data.split(b'\r\n'):
            if line.lower().startswith(b'x-real-host:'):
                host = line.split(b':', 1)[1].strip()
                break

        # Conectar al destino
        target_host, target_port = host.split(b':')
        target_port = int(target_port)

        remote = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        remote.connect((target_host.decode(), target_port))

        # Respuesta HTTP falsa
        client_socket.sendall(RESPONSE)

        # Enviar datos restantes (si existen)
        remain = data.split(b'\r\n\r\n', 1)
        if len(remain) > 1 and remain[1]:
            remote.sendall(remain[1])

        sockets = [client_socket, remote]

        while True:
            readable, _, _ = select.select(sockets, [], [])
            for sock in readable:
                other = remote if sock is client_socket else client_socket
                payload = sock.recv(BUFFER_SIZE)
                if not payload:
                    client_socket.close()
                    remote.close()
                    return
                other.sendall(payload)

    except Exception:
        try:
            client_socket.close()
        except:
            pass


def start_server():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((LISTEN_ADDR, LISTEN_PORT))
    server.listen(200)

    print(f"[PDirect3] Listening on {LISTEN_ADDR}:{LISTEN_PORT}")

    while True:
        client, addr = server.accept()
        thread = threading.Thread(target=handle_client, args=(client,))
        thread.daemon = True
        thread.start()


if __name__ == "__main__":
    start_server()
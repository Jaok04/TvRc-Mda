#!/bin/bash
# 8.5 FIX + Python3 DIRECTO
clear
clear

SCPdir="/etc/VPS-MX"
SCPfrm="${SCPdir}/herramientas" && [[ ! -d ${SCPfrm} ]] && exit
SCPinst="${SCPdir}/protocolos" && [[ ! -d ${SCPinst} ]] && exit

declare -A cor=( [0]="\033[1;37m" [1]="\033[1;34m" [2]="\033[1;31m" [3]="\033[1;33m" [4]="\033[1;32m" )

# ========= PYTHON =========
if command -v python2 >/dev/null 2>&1; then
  PY2=python2
elif command -v python >/dev/null 2>&1; then
  PY2=python
else
  PY2=""
fi

command -v python3 >/dev/null 2>&1 || apt-get install python3 -y &>/dev/null

# ========= IP =========
meu_ip () {
  IP_LOCAL=$(ip -4 route get 1.1.1.1 2>/dev/null | awk '{print $7; exit}')
  IP_PUBLIC=$(wget -qO- ipv4.icanhazip.com)
  [[ -n "$IP_PUBLIC" ]] && echo "$IP_PUBLIC" || echo "$IP_LOCAL"
}

# ========= MATAR PROCESOS =========
pid_kill () {
  [[ -z $1 ]] && return
  for pid in "$@"; do
    kill -9 "$pid" &>/dev/null
  done
}

remove_fun () {
  msg -bar
  echo -e " Parando Socks Python"
  msg -bar
  pkill -f PPub.py
  pkill -f PPriv.py
  pkill -f PDirect.py
  pkill -f PDirect3.py
  pkill -f POpen.py
  pkill -f PGet.py
  pkill -f scktcheck
  rm -rf /etc/VPS-MX/PortPD.log
  echo "" > /etc/VPS-MX/PortPD.log
  msg -bar
  sleep 1
}

# ========= PYTHON DIRECTO PY2 =========
PythonDic_fun () {
  [[ -z "$PY2" ]] && {
    echo -e "\033[1;31m Python2 no disponible"
    sleep 2
    return
  }
  screen -dmS pydirect2 $PY2 ${SCPinst}/PDirect.py "$porta_socket"
  echo "$porta_socket" >/etc/VPS-MX/py.log
}

# ========= MENU =========
iniciarsocks () {

 pidproxy=$(pgrep -f PPub.py)        && P1="[ON]" || P1="[OFF]"
 pidproxy2=$(pgrep -f PPriv.py)      && P2="[ON]" || P2="[OFF]"
 pidproxy3=$(pgrep -f PDirect.py)    && P3="[ON]" || P3="[OFF]"
 pidproxy7=$(pgrep -f PDirect3.py)   && P7="[ON]" || P7="[OFF]"
 pidproxy4=$(pgrep -f POpen.py)      && P4="[ON]" || P4="[OFF]"
 pidproxy5=$(pgrep -f PGet.py)       && P5="[ON]" || P5="[OFF]"
 pidproxy6=$(pgrep -f scktcheck)     && P6="[ON]" || P6="[OFF]"

 msg -bar
 msg -ama "   INSTALADOR DE PROXY'S VPS-MX 8.5"
 msg -bar

 echo -e "[1] Proxy Python SIMPLE (Py2)      $P1"
 echo -e "[2] Proxy Python SEGURO (Py3)      $P2"
 echo -e "[3] Proxy Python DIRECTO (Py2)     $P3"
 echo -e "[4] Proxy Python DIRECTO (Py3)     $P7"
 echo -e "[5] Proxy Python OPENVPN           $P4"
 echo -e "[6] Proxy Python GETTUNEL          $P5"
 echo -e "[7] Proxy Python TCP BYPASS        $P6"
 echo -e "[8] PARAR TODOS LOS PROXY"
 echo -e "[0] VOLVER"
 msg -bar

 IP=$(meu_ip)

 while [[ -z $portproxy || $portproxy != @(0|[1-8]) ]]; do
   read -p "Digite una opcion: " portproxy
 done

 case $portproxy in
   1) screen -dmS pypub $PY2 ${SCPinst}/PPub.py "$porta_socket" "$texto_soket" ;;
   2) screen -dmS pypriv python3 ${SCPinst}/PPriv.py "$porta_socket" "$texto_soket" "$IP" ;;
   3) PythonDic_fun ;;
   4) screen -dmS pydirect3 python3 ${SCPinst}/PDirect3.py "$porta_socket" ;;
   5) screen -dmS pyopen $PY2 ${SCPinst}/POpen.py "$porta_socket" "$texto_soket" ;;
   6) gettunel_fun "$porta_socket" ;;
   7) tcpbypass_fun "$porta_socket" "$texto_soket" ;;
   8) remove_fun ;;
   0) return ;;
 esac

 msg -bar
 echo -e " Procedimiento COMPLETO"
 msg -bar
}

iniciarsocks
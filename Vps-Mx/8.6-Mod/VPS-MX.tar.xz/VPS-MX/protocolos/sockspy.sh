#!/bin/bash

SCPinst="/etc/VPS-MX/protocolos"

# ================================
# Detectar Python
# ================================
if command -v python2 >/dev/null 2>&1; then
  PY2=python2
elif command -v python >/dev/null 2>&1; then
  PY2=python
else
  PY2=""
fi

command -v python3 >/dev/null 2>&1 || apt-get install python3 -y &>/dev/null

# ================================
# Obtener IP correcta
# ================================
meu_ip() {
  IP_LOCAL=$(ip -4 route get 1.1.1.1 2>/dev/null | awk '{print $7; exit}')
  IP_PUBLIC=$(wget -qO- ipv4.icanhazip.com)
  [[ -n "$IP_PUBLIC" ]] && echo "$IP_PUBLIC" || echo "$IP_LOCAL"
}

# ================================
# Detener proxies
# ================================
remove_fun() {
  pkill -f PPub.py
  pkill -f PPriv.py
  pkill -f PDirect.py
  pkill -f PDirect3.py
  pkill -f POpen.py
  pkill -f scktcheck
  msg -bar
  echo -e "\033[1;31m Proxys detenidos"
  msg -bar
  sleep 1
}

# ================================
# Selector visual
# ================================
selecionador() {
  msg -bar
  echo -e "\033[1;32m Iniciando servicio..."
  msg -bar
  sleep 1
}

# ================================
# PYTHON DIRECTO (Py2)
# ================================
PythonDic_fun() {
  [[ -z "$PY2" ]] && {
    echo -e "\033[1;31m Python2 no disponible"
    sleep 2
    return
  }
  selecionador
  screen -dmS pydirect2 $PY2 ${SCPinst}/PDirect.py "$porta_socket"
  echo "$porta_socket" >/etc/VPS-MX/py.log
}

# ================================
# MENU PRINCIPAL
# ================================
iniciarsocks() {

 pidproxy=$(pgrep -f PPub.py)        && P1="\033[1;32m[ON]" || P1="\033[1;31m[OFF]"
 pidproxy2=$(pgrep -f PPriv.py)      && P2="\033[1;32m[ON]" || P2="\033[1;31m[OFF]"
 pidproxy3=$(pgrep -f PDirect.py)    && P3="\033[1;32m[ON]" || P3="\033[1;31m[OFF]"
 pidproxy7=$(pgrep -f PDirect3.py)   && P7="\033[1;32m[ON]" || P7="\033[1;31m[OFF]"
 pidproxy4=$(pgrep -f POpen.py)      && P4="\033[1;32m[ON]" || P4="\033[1;31m[OFF]"
 pidproxy5=$(pgrep -f PGet.py)       && P5="\033[1;32m[ON]" || P5="\033[1;31m[OFF]"
 pidproxy6=$(pgrep -f scktcheck)     && P6="\033[1;32m[ON]" || P6="\033[1;31m[OFF]"

 msg -bar
 echo -e "    \e[91m\e[43m INSTALADOR DE PROXY'S \e[0m"
 msg -bar

 echo -e " [1] Proxy Python SIMPLE (Py2)        $P1"
 echo -e " [2] Proxy Python SEGURO (Py3)        $P2"
 echo -e " [3] Proxy Python DIRECTO (Py2)       $P3"
 echo -e " [4] Proxy Python DIRECTO (Py3)       $P7"
 echo -e " [5] Proxy Python OPENVPN             $P4"
 echo -e " [6] Proxy Python GETTUNEL            $P5"
 echo -e " [7] Proxy Python TCP BYPASS          $P6"
 echo -e " [8] DETENER SERVICIO PYTHON"
 msg -bar
 echo -e " [0] VOLVER"
 msg -bar

 IP=$(meu_ip)

 while [[ -z $portproxy || $portproxy != @(0|[1-8]) ]]; do
   read -p " Digite una opcion: " portproxy
 done

 case $portproxy in
   1)
     selecionador
     screen -dmS pypub $PY2 ${SCPinst}/PPub.py "$porta_socket" "$texto_soket"
   ;;
   2)
     selecionador
     screen -dmS pypriv python3 ${SCPinst}/PPriv.py "$porta_socket" "$texto_soket" "$IP"
   ;;
   3)
     PythonDic_fun
   ;;
   4)
     selecionador
     screen -dmS pydirect3 python3 ${SCPinst}/PDirect3.py "$porta_socket"
     echo "$porta_socket" >/etc/VPS-MX/py.log
   ;;
   5)
     selecionador
     screen -dmS pyopen $PY2 ${SCPinst}/POpen.py "$porta_socket" "$texto_soket"
   ;;
   6)
     selecionador
     gettunel_fun "$porta_socket"
   ;;
   7)
     selecionador
     tcpbypass_fun "$porta_socket" "$texto_soket"
   ;;
   8)
     remove_fun
   ;;
   0)
     return
   ;;
 esac

 echo -e "\033[1;32m Procedimiento COMPLETO"
 msg -bar
}

iniciarsocks